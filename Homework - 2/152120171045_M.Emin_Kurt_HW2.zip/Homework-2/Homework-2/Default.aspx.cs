﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data.SqlClient;

namespace Homework_2
{
    public partial class Default : System.Web.UI.Page
    {
        /*static string kelime = "";
        static string ipucuu = "";

        static bool flag = true;*/

        static int sayac = 0;

        static int kalanHakk = 7;
        static string[] bulunan_harfler;

        static int count;
        static Random rnd = new Random();
        static int myNumber = rnd.Next(0, setWords.counter);
        static string myGuess = setWords.wordss[myNumber];
        static string myDesc = setWords.descss[myNumber];

        protected void Page_Load(object sender, EventArgs e)
        {
            bulunan_harfler = new string[myGuess.Length];

            for (int i = 0; i < myGuess.Length; i++)
            {
                bulunan_harfler[i] = "_ "; // İlk harfler bulunmadığı için _ koyuyoruz. 
                lblReal.Text += bulunan_harfler[i].ToString();
            }


            kalanHak.Text = "Kalan Hak: " + kalanHakk.ToString();


            //Label1.Text = myGuess;

            //int llength = myGuess.Length;

            /*if (llength == 4)
                lblReal.Text = "_ _ _ _";
            if (llength == 5)
                lblReal.Text = "_ _ _ _ _";
            if (llength == 6)
                lblReal.Text = "_ _ _ _ _ _";*/

        }
        protected void imageShow()
        {
            if (count == 1)
                Image1.ImageUrl = "Images/1.jpg";
            else if (count == 2)
                Image1.ImageUrl = "Images/4.jpg";
            else if (count == 3)
                Image1.ImageUrl = "Images/6.jpg";
            else if (count == 4)
                Image1.ImageUrl = "Images/7.jpg";
            else if (count == 5)
                Image1.ImageUrl = "Images/8.jpg";
            else if (count == 6)
                Image1.ImageUrl = "Images/9.jpg";
            else if (count == 7)
                Image1.ImageUrl = "Images/10.jpg";
        }
        protected void playGame(Button btn)
        {

            char character = char.Parse(btn.Text);

            if (!(myGuess.Contains<char>(character)))
            {
                count++;
                kalanHakk--;
                kalanHak.Text = "Kalan Hak: " + kalanHakk.ToString();
            }
            else
            {
                //Label10.Text = btn.Text;
                //lblReal.Text = "";

                if (lblReal.Text == myGuess)
                {
                    lblReal.Text = "YOU WIN :)";
                }
            }

            if (count == 7)
            {
                lblReal.Text = "YOU LOSE, LOSER!";
            }

        }
        protected void btnRestart_Click(object sender, EventArgs e)
        {
            count = 0;
            Image1.ImageUrl = "Images/0.jpg";
        }

        protected void btnA_Click1(object sender, EventArgs e)
        {
            playGame(btnA);
            imageShow();
        }

        protected void btnB_Click(object sender, EventArgs e)
        {
            playGame(btnB);
            imageShow();
        }

        protected void btnC_Click(object sender, EventArgs e)
        {
            playGame(btnC);
            imageShow();
        }

        protected void btnÇ_Click(object sender, EventArgs e)
        {
            playGame(btnÇ);
            imageShow();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("setWords.aspx");

        }

        protected void btnD_Click(object sender, EventArgs e)
        {
            playGame(btnD);
            imageShow();
        }

        protected void btnE_Click(object sender, EventArgs e)
        {
            playGame(btnE);
            imageShow();
        }

        protected void btnF_Click(object sender, EventArgs e)
        {
            playGame(btnF);
            imageShow();
        }

        protected void btnG_Click(object sender, EventArgs e)
        {
            playGame(btnG);
            imageShow();
        }

        protected void btnĞ_Click(object sender, EventArgs e)
        {
            playGame(btnĞ);
            imageShow();
        }

        protected void btnH_Click(object sender, EventArgs e)
        {
            playGame(btnH);
            imageShow();
        }

        protected void btnI_Click(object sender, EventArgs e)
        {
            playGame(btnI);
            imageShow();
        }

        protected void btnİ_Click(object sender, EventArgs e)
        {
            playGame(btnİ);
            imageShow();
        }

        protected void btnJ_Click(object sender, EventArgs e)
        {
            playGame(btnJ);
            imageShow();
        }

        protected void btnK_Click(object sender, EventArgs e)
        {
            playGame(btnK);
            imageShow();
        }

        protected void btnL_Click(object sender, EventArgs e)
        {
            playGame(btnL);
            imageShow();
        }

        protected void btnM_Click(object sender, EventArgs e)
        {
            playGame(btnM);
            imageShow();
        }

        protected void btnN_Click(object sender, EventArgs e)
        {
            playGame(btnN);
            imageShow();
        }

        protected void btnO_Click(object sender, EventArgs e)
        {
            playGame(btnO);
            imageShow();
        }

        protected void btnÖ_Click(object sender, EventArgs e)
        {
            playGame(btnÖ);
            imageShow();
        }

        protected void btnP_Click(object sender, EventArgs e)
        {
            playGame(btnP);
            imageShow();
        }

        protected void btnR_Click(object sender, EventArgs e)
        {
            playGame(btnR);
            imageShow();
        }

        protected void btnS_Click(object sender, EventArgs e)
        {
            playGame(btnS);
            imageShow();
        }

        protected void btnŞ_Click(object sender, EventArgs e)
        {
            playGame(btnŞ);
            imageShow();
        }

        protected void btnT_Click(object sender, EventArgs e)
        {
            playGame(btnT);
            imageShow();
        }

        protected void btnU_Click(object sender, EventArgs e)
        {
            playGame(btnU);
            imageShow();
        }

        protected void btnÜ_Click(object sender, EventArgs e)
        {
            playGame(btnÜ);
            imageShow();
        }

        protected void btnV_Click(object sender, EventArgs e)
        {
            playGame(btnV);
            imageShow();
        }

        protected void btnY_Click(object sender, EventArgs e)
        {
            playGame(btnY);
            imageShow();
        }

        protected void btnZ_Click(object sender, EventArgs e)
        {
            playGame(btnZ);
            imageShow();
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {

            if (sayac % 2 == 0)
                Label1.Text = myDesc;
            else
                Label1.Text = myGuess;

            sayac++;

        }
    }
}