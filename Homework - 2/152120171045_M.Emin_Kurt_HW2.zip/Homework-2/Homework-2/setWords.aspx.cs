﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Homework_2
{
    public partial class setWords : System.Web.UI.Page
    {
        public static List<string> wordss = new List<string> {
            "PORTAKAL", "MERCEDES", "BİLGİSAYAR", "AĞAÇ", "KARPUZ", "TUTUNAMAYANLAR", "LEYLEK", "PANDA", "TEKERLEK",
            "UÇURTMA", "ÇAYDANLIK", "KÖPRÜ"
        };
        public static List<string> descss = new List<string> {
            "bir meyve çeşidi", "bir araba markası", "bir elektronik eşya", "oksijen kaynağı", "bir yaz meyvesi",
            "bir oğuz atay romanı", "bir kuş çeşidi", "siyah beyaz bir hayvan", "bir çeşit araç bileşeni",
            "rüzgarlı havalarda uçurulan eğlence aracı", "çay yapmaya yarayan bir alet", "iki kara parçasını birbirine bağlayan yapı"
        };

        public static int counter=wordss.Count;
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
        {

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            string word = txtWordAdd.Text;
            string desc = txtDescAdd.Text;

            wordss.Add(word);
            descss.Add(desc);

            SqlConnection connection = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            SqlCommand add = new SqlCommand("INSERT INTO myWordList (Words, Description) VALUES (@_word, @_desc)", connection);
            add.Parameters.AddWithValue("@_kelime", word);
            add.Parameters.AddWithValue("@_ipucu", desc);
            connection.Open();
            add.ExecuteNonQuery();
            connection.Close();
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            string word = txtWordDelete.Text;
            SqlConnection connection = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["connection"].ConnectionString);
            SqlCommand delete = new SqlCommand("DELETE FROM myWordList WHERE Words=@_word", connection);
            delete.Parameters.AddWithValue("@_kelime", word);
            connection.Open();
            delete.ExecuteNonQuery();
            connection.Close();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }
    }
}