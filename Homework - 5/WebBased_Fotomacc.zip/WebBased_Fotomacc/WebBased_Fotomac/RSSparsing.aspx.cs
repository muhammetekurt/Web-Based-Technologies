﻿using Serilog;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace webFinal
{
    public partial class RSSparsing : System.Web.UI.Page
    {
        private DatabaseHandler dh = DatabaseHandler.getInitial();
        ArrayList allNews = new ArrayList();
        protected void Page_Load(object sender, EventArgs e)
        {
            parseXML("https://t24.com.tr/rss/haber/gundem", "Agenda");
            parseXML("https://t24.com.tr/rss/haber/bilim-teknoloji", "Technology");//turkiye
            parseXML("https://t24.com.tr/rss/haber/kultur-sanat", "Arts");
            parseXML("https://t24.com.tr/rss/haber/spor", "Sports");
            parseXML("https://t24.com.tr/rss/haber/dunya", "World");
            parseXML("https://t24.com.tr/rss/haber/saglik", "Health");
            parseXML("https://t24.com.tr/rss/haber/dunya-basininda-bugun", "Breaking News");

            Log.Logger = new LoggerConfiguration()
                .WriteTo.File("C:\\Users\\mekur\\Desktop\\WebBased_Fotomacc\\WebBased_Fotomac\\Log\\log.txt", rollingInterval: RollingInterval.Day)
                .CreateLogger();
        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            Session["todayNews"] = allNews;
            Response.Redirect("Home.aspx");
        }

        protected void parseXML(string url, string category)
        {
            XmlDocument rssXmlDoc = new XmlDocument();
            try
            {
                rssXmlDoc.Load(url);
                XmlNodeList rssNodes = rssXmlDoc.SelectNodes("rss/channel/item");
                foreach (XmlNode rssNode in rssNodes)
                {
                    XmlNode rssSubNode = rssNode.SelectSingleNode("title");
                    string title = rssSubNode != null ? rssSubNode.InnerText : "";

                    rssSubNode = rssNode.SelectSingleNode("link");
                    string newLink = rssSubNode != null ? rssSubNode.InnerText : "";

                    rssSubNode = rssNode.SelectSingleNode("description");
                    string description = rssSubNode != null ? rssSubNode.InnerText : "";

                    string author = "T24 Yeni Medya Kanal Koordinatörlüğü";

                    DateTime pubDate = DateTime.Today;

                    rssSubNode = rssNode.SelectSingleNode("enclosure");

                    string imageUrl = "";
                    if (rssSubNode != null)
                    {
                        imageUrl = rssSubNode.Attributes["url"].Value;
                    }

                    News tempNews = new News(0, title, description, category, author, newLink, pubDate, imageUrl);

                    allNews.Add(tempNews);

                    if (dh.getNewsCount(title) < 1)
                    {
                        dh.addNew(tempNews);
                    }
                }
                Log.Logger.Information("RSS'ler basarili bir sekilde yuklendi.");
            }
            catch
            {
                Log.Logger.Error("RSS'ler yuklenemedi.");
            }
        }
    }
}