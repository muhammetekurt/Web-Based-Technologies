#Muhammet EMİN KURT
#152120171045


#Homework Nasıl Çalıştırılır?


1) DatabaseHandler'daki connection adresi path değiştirilir...
 
private static OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=  " Değiştir "   \main.mdb;Persist Security Info=True");


2) RSSParsing.aspx.cs dosyasındaki log file path değiştirilir

  Log.Logger = new LoggerConfiguration()
                .WriteTo.File( " Değiştir "   Log\\log.txt", rollingInterval: RollingInterval.Day)
                .CreateLogger();

3)Son olarak Homework RSSParsing.aspx.cs dosyasında çalıştırılır.. 




